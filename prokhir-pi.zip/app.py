# app.py
from flask import Flask, jsonify
from backend_handler import get_query

app = Flask(__name__)

@app.route("/")
def hello_world():
    return "<p>Hello, World!</p>"

@app.route('/query/<parameter>', methods=['GET'])
def get_data(parameter):
    # Panggil program C dan ambil outputnya
    query_result = get_query(parameter)

    if query_result:
        # Persiapkan respons JSON
        response = {
            'words': query_result.words,
            'distinct_terms': query_result.distinct_terms,
            'top_documents': query_result.top_documents
        }

        # Jika kata tidak terdaftar atau query hanya terdiri dari stopword
        if not query_result.words:
            response['error'] = 'Word is not indexed or all query terms are stopword'
            response['words'] = None
            response['top_documents'] = None

        # Return hasil dalam bentuk JSON
        return jsonify(response)
    else:
        return jsonify({'error': 'Error running C program'}), 500

if __name__ == '__main__':
    app.run(debug=True)
